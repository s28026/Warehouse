const DashboardDriverUnloadPage = () => {
  return (
    <div>
      <h1>Driver Unload Page</h1>
      <p>This is the unload page for drivers.</p>
    </div>
  );
};

export default DashboardDriverUnloadPage;
