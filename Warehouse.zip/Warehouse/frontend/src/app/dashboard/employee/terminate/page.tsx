const DashboardEmployeeTerminatePage = () => {
  return (
    <div>
      <h1>Terminate Employee</h1>
      <p>This page will allow you to terminate an employee.</p>
      {/* Add your termination form or logic here */}
    </div>
  );
};

export default DashboardEmployeeTerminatePage;
