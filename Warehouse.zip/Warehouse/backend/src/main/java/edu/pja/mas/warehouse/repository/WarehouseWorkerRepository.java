package edu.pja.mas.warehouse.repository;

import edu.pja.mas.warehouse.entity.WarehouseWorker;
import org.springframework.data.repository.CrudRepository;


public interface WarehouseWorkerRepository extends CrudRepository<WarehouseWorker, Long> {
    WarehouseWorker findByWarehouseEmployee_Id(Long warehouseEmployeeId);
}
