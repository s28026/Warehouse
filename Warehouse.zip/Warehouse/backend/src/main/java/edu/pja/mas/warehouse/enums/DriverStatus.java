package edu.pja.mas.warehouse.enums;

public enum DriverStatus {
    AVAILABLE,
    UNAVAILABLE,
    ON_BREAK,
    RESERVED
}
