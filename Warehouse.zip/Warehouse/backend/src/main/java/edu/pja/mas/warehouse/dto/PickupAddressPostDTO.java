package edu.pja.mas.warehouse.dto;

public record PickupAddressPostDTO(
        String address
) {
}
