package edu.pja.mas.warehouse.enums;

public enum SmsStatus {
    ACCEPTED,
    REJECTED,
    TIMEOUT
}

