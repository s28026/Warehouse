package edu.pja.mas.warehouse.enums;

public enum WarehouseEmployeeType {
    OPERATOR,
    WORKER
}
