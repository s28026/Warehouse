package edu.pja.mas.warehouse.dto;

public record WarehousePostDTO(
        String location
) {
}
