package edu.pja.mas.warehouse.enums;

public enum EmployeeType {
    DELIVERY_DRIVER,
    WAREHOUSE_EMPLOYEE
}
