package edu.pja.mas.warehouse.dto;

public record WarehouseWorkerPostDTO(
        int capacity
) {
}
