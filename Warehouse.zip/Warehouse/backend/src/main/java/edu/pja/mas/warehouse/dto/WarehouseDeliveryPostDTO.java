package edu.pja.mas.warehouse.dto;

public record WarehouseDeliveryPostDTO(
        Long warehouseId
) {
}
